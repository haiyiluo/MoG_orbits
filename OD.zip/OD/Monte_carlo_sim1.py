import matplotlib.pyplot as plt
import numpy as np

'''square=plt.Rectangle((-1,-1), 2,2)
circle=plt.Circle((0,0),1,edgecolor='red', facecolor='none', linewidth=2, label='Rectangle')

fig, ax = plt.subplots()
ax.add_patch(square)
ax.add_patch(circle)
'''
diff_squared=0
x_sum=0
for ii in range(10):
        x=np.random.uniform(0,1,1000)
        y=np.random.uniform(0,1,1000)
        count=0
        for i in x:
            for j in y:
                if (i**2 + j**2)**0.5<=1:
                    count+=1
        
        experimental=(count/1000**2)*4
        diff_squared+=(experimental-np.pi)**2
        x_sum+=experimental
        print(experimental )
        print((experimental-3.14)/3.14,'%')


std=(1/(10-1)*diff_squared)
mean=1/10*x_sum
print('mean',mean)
print('std',std)







'''plt.scatter(x, y, color='blue', alpha=0.7, edgecolors='black')'''


'''# Set the limits and aspect ratio
ax.set_xlim(-2,2)
ax.set_ylim(-2, 2)
ax.set_aspect('equal')



# Display the plot
plt.show()'''



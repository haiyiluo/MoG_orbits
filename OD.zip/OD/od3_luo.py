import numpy as np

# Earth's obliquity in radians
epsilon = np.deg2rad(23.5)

# Newton-Raphson method to solve Kepler's Equation: E - e*sin(E) = M
def newton(initial_guess: float, M: float, e: float) -> float:
    E_prev = (initial_guess)
    M=(M)
    tol = 1e-6
    max_iter = 100
    for _ in range(max_iter):
        f = E_prev - e * np.sin(E_prev) - M
        f_prime = 1 - e * np.cos(E_prev)
        E_new = E_prev - f / f_prime
        if np.abs(E_new - E_prev) < tol:
            return (E_new)
        E_prev = E_new



# Calculate proper quadrant of angle from sine and cosine
def angle_from_sin_cos(sin_val, cos_val):
    angle = np.arctan2(sin_val, cos_val)
    if sin_val<0 and cos_val < 0:
        angle += 2 * np.pi
    elif sin_val<0 and cos_val < 0:
        angle-=np.pi
    else:
        return angle

# Gravitational parameter (normalized)
MU = 1

def orbit_elements(fname: str):
    with open(fname, "r", encoding="utf-8") as f:
        lines = [line.strip() for line in f if line.strip()]

    # Orbital elements
    a = float(lines[0])         
    e = float(lines[1])            
    i = np.deg2rad(float(lines[2]))         
    Omega = np.deg2rad(float(lines[3]))         
    omega =np.deg2rad(float(lines[4]))      
    M = np.deg2rad(float(lines[5]))      

    '''k=0.01720209894 
    μ=1.000000
    n=k*(μ/a**3)**0.5
    M=n*(t-T)'''

    # Sun vector from JPL, converted to AU
    Rx = float(lines[6]) 
    Ry = float(lines[7]) #/ 1.495978707e8
    Rz = float(lines[8]) #/ 1.495978707e8

    # Solve Kepler's Equation for eccentric anomaly E
    E = newton(initial_guess=1, M=M, e=e)


    # Position in orbital plane
    r_orb = np.array([
        a * (np.cos(E) - e),
        a * np.sqrt(1 - e**2) * np.sin(E),
        0
    ])

    # Rotation matrices: ω (perihelion), i (inclination), Ω (ascending node)
    R_omega = np.array([
        [np.cos(omega), -np.sin(omega), 0],
        [np.sin(omega),  np.cos(omega), 0],
        [0,              0,             1]
    ])
    mat1=R_omega@r_orb

    R_i = np.array([
        [1, 0, 0],
        [0, np.cos(i), -np.sin(i)],
        [0, np.sin(i),  np.cos(i)]
    ])
    mat2=R_i@mat1

    R_Omega = np.array([
        [np.cos(Omega), -np.sin(Omega), 0],
        [np.sin(Omega),  np.cos(Omega), 0],
        [0,              0,             1]
    ])
    r_ecliptic=R_Omega@mat2


    # Rotate from ecliptic to equatorial coordinates
    R_obliquity = np.array([
        [1, 0, 0],
        [0, np.cos(epsilon), -np.sin(epsilon)],
        [0, np.sin(epsilon),  np.cos(epsilon)]
    ])
    r_equatorial = R_obliquity @ r_ecliptic
    print ('r_equatorial', r_equatorial)
    # Vector from observer to body (topocentric)
    rho_vec = np.array([Rx, Ry, Rz]) + r_equatorial
    rho_mag = np.linalg.norm(rho_vec)
    rho_hat = rho_vec / rho_mag

    # Convert to RA/Dec
    dec = np.arcsin(rho_hat[2])
    #ra = angle_from_sin_cos(rho_hat[1] / np.cos(dec), rho_hat[0] / np.cos(dec))
    ra= (np.arcsin(rho_hat[1] / np.cos(dec)))
    
    if rho_hat[0] / np.cos(dec) > 0:
        ra = ra % (2*np.pi)
    elif rho_hat[0] / np.cos(dec) < 0:
        ra = np.pi - ra

    print(f"Mean anomaly (deg): {M:.4f}")
    print(f"Solved Eccentric Anomaly (deg): {E:.4f}")
    print(f"Direction Vector (unit): {rho_hat}")
    print(f"RA: {np.rad2deg(ra)/15:.4f} hr, Dec: {np.rad2deg(dec):.4f} deg")

    return  np.rad2deg(ra)/15, np.rad2deg(dec)

# Comparison function
def comp_err(tol, real, test):
    results = []
    for i in range(len(real)):
        if abs(real[i] - test[i]) < tol:
            results.append(f'Error within tolerance at index {i}')
        else:
            results.append(f'Error exceeds tolerance at index {i}')
    return results

real=orbit_elements('od2_test.txt')
test=[]

# Run the orbital element calculation
print(orbit_elements('od2_test.txt'))

''#given: time in JD, ra and dec, sun vectors
#get: position and velocity elements, distance between observer and asteroid at a given time, orbital elements

# first: convert ra and dec to v and r
import numpy as np
import re
import csv
from OD2_Luo import *
from astropy.io import fits

#tbl = fits.open("corr.fits")[1].data
#rms_ra = 3600*(np.mean((tbl.field_ra - tbl.index_ra)**2.))**0.5


def parse_ra_string(ra_string: str) -> tuple[int, int, float]:
    parts = re.split(r"[:\s]+", ra_string.strip())
    h, m, s = int(parts[0]), int(parts[1]), float(parts[2])
    return h, m, s

def parse_dec_string(dec_string: str) -> tuple[int, int, float, bool]:
    dec_string = dec_string.strip()
    is_neg = dec_string[0] == "-"
    parts = re.split(r"[:\s]+", dec_string[1:])  # Skip sign
    d, m, s = int(parts[0]), int(parts[1]), float(parts[2])
    return d, m, s, is_neg

def convert_hms_to_deg(h: int, m: int, s: float) -> float:
    return 15.0 * (h + m / 60 + s / 3600)

def convert_dms_to_deg(d: int, m: int, s: float, is_neg: bool) -> float:
    deg = d + m / 60 + s / 3600
    return -deg if is_neg else deg

def f_g(r:np.array, v:np.array, tau):
    r_mag=np.linalg.norm(r) #magnitude of the vector
    f=1-tau**2/(2*r_mag**3)+np.dot(r,v)*tau**3/(2*r_mag**5)+tau**4/(24*r_mag**3)*(3*(np.dot(v,v)/r_mag**2-1/r_mag**3)-15*(np.dot(r,v)/r_mag**2)**2+1/r_mag**3)

    g=tau-tau**3/(6*r_mag**3)+np.dot(r,v)*tau**4/(4*r_mag**5)
    return f,g
    
def compD(fname):
    
    epsilon=np.deg2rad(-23.4383017319)
    R_obliquity = np.array([
        [1, 0, 0],
        [0, np.cos(epsilon), -np.sin(epsilon)],
        [0, np.sin(epsilon),  np.cos(epsilon)]
    ])
    inverse_r_obliquity=np.array([
        [1, 0, 0],
        [0, np.cos(epsilon), np.sin(epsilon)],
        [0, -np.sin(epsilon), np.cos(epsilon)]
    ])

    def rho_hat(ra_s, dec_s):
        ra_deg = convert_hms_to_deg(*parse_ra_string(ra_s))
        dec_deg = convert_dms_to_deg(*parse_dec_string(dec_s))
        ra_rad = np.deg2rad(ra_deg)
        dec_rad = np.deg2rad(dec_deg)

        print('dec_rad:', dec_rad)
        return np.array([
            np.cos(ra_rad) * np.cos(dec_rad),
            np.sin(ra_rad) * np.cos(dec_rad),
            np.sin(dec_rad)
        ])
    
    def percent_error(est, true):
        est = np.array(est)
        true = np.array(true)
        return np.abs((est - true) / true) * 100
    
    
    # Open the CSV file
    with open(fname, 'r') as file:    
        reader = csv.reader(file)
        next(reader) #getting rid pf the header
    # Process each row
        for row in reader:
        # Strip whitespace from each element in the row
            stripped_row = [element.strip() for element in row]
            ra1s, dec1s, r1 = (stripped_row[2]),(stripped_row[3]), inverse_r_obliquity@np.array([float(stripped_row[4]),float(stripped_row[5]),float(stripped_row[6])])
            ra2s, dec2s, r2 = (stripped_row[8]), (stripped_row[9]), inverse_r_obliquity@np.array([float(stripped_row[10]),float(stripped_row[11]),float(stripped_row[12])])
            ra3s, dec3s, r3 = (stripped_row[14]),(stripped_row[15]), inverse_r_obliquity@np.array([float(stripped_row[16]),float(stripped_row[17]),float(stripped_row[18])])
            
            print("RADEC", ra1s, ra2s, ra3s)
            print(dec1s, dec2s, dec3s)
            #r_jpl = np.array([float(stripped_row[20]), float(stripped_row[21]), float(stripped_row[22])])
            #v_jpl = np.array([float(stripped_row[23]), float(stripped_row[24]), float(stripped_row[25])])
            orbital_jpl = [float(stripped_row[27]), float(stripped_row[28]), float(stripped_row[29]),float(stripped_row[30]), float(stripped_row[31]), float(stripped_row[32])]

            #print("jpl", r_jpl, v_jpl, orbital_jpl)
            ρ1hat = rho_hat(ra1s, dec1s)
            ρ2hat= rho_hat(ra2s, dec2s)
            ρ3hat = rho_hat(ra3s, dec3s)
            print('rhohat',  ρ1hat, ρ2hat, ρ3hat)
            R1 = np.array(r1)
            R2 = np.array(r2)
            R3 = np.array(r3)

            print('sun vectors:', R1, R2, R3)

            t1=float(stripped_row[1])
            t2=float(stripped_row[7])
            t3=float(stripped_row[13])

            k=2*np.pi/365.2568983
            tau1=k*(t1-t2)
            tau0=k*(t3-t1)
            tau3=k*(t3-t2)
            


            #initial values for a1, a2, a3
            a1=tau3/tau0
            a3=-tau1/tau0
            #print('as', a1, a3)
            #initial values for rhos

            print(f"t1, t2, t3: {(t1, t2, t3)}")

            

            rho1=(a1*(np.dot(np.cross(R1,ρ2hat),ρ3hat))-np.dot(np.cross(R2,ρ2hat),ρ3hat)+a3*np.dot(np.cross(R3,ρ2hat),ρ3hat))/(a1*np.dot(np.cross(ρ1hat,ρ2hat),ρ3hat))
            rho2=(a1*(np.dot(np.cross(ρ1hat,R1),ρ3hat))-np.dot(np.cross(ρ1hat,R2),ρ3hat)+a3*np.dot(np.cross(ρ1hat,R3),ρ3hat))/-(np.dot(np.cross(ρ1hat,ρ2hat),ρ3hat))
            rho3=(a1*(np.dot(np.cross(ρ2hat,R1),ρ1hat))-np.dot(np.cross(ρ2hat,R2),ρ1hat)+a3*np.dot(np.cross(ρ2hat,R3),ρ1hat))/(a3*np.dot(np.cross(ρ2hat,ρ3hat),ρ1hat))
            print('rhos:', rho1, rho2, rho3)

            #initial values for three r vectors (unites: AU)
            r1=rho1*ρ1hat-R1
            r2=rho2*ρ2hat-R2
            r3=rho3*ρ3hat-R3

            v12=(r2-r1)/(t2-t1)
            v23=(r3-r2)/(t3-t2) #where r1,2,3 are all vectors 

            v2=((t3-t2)*v12+(t2-t1)*v23)/(t3-t1)
            print('r2, v2', r2, v2)
            f_initial_guess1=f_g(r2, v2, tau1)[0]
            g_initial_guess1=f_g(r2, v2, tau1)[1]
            
            f_initial_guess3=f_g(r2, v2, tau3)[0]
            g_initial_guess3=f_g(r2, v2, tau3)[1]

            print('f, g', f_initial_guess1, f_initial_guess3, g_initial_guess1, g_initial_guess3)


            a1_recal=g_initial_guess3/(f_initial_guess1*g_initial_guess3-f_initial_guess3*g_initial_guess1)
            a3_recal=g_initial_guess1/(f_initial_guess1*g_initial_guess3-f_initial_guess3*g_initial_guess1)
            print('recal:',a1_recal, a3_recal)
            #main loop here
            r2_new=[1,1,1]
            v2_new=[1,1,1]
            count=0
            while np.abs((np.linalg.norm(r2_new)-np.linalg.norm(r2))/np.linalg.norm(r2_new))>10**(-10):
                rho1=(a1_recal*(np.dot(np.cross(R1,ρ2hat),ρ3hat))-np.dot(np.cross(R2,ρ2hat),ρ3hat)+a3_recal*np.dot(np.cross(R3,ρ2hat),ρ3hat))/(a1_recal*np.dot(np.cross(ρ1hat,ρ2hat),ρ3hat))
                rho2=(a1_recal*(np.dot(np.cross(ρ1hat,R1),ρ3hat))-np.dot(np.cross(ρ1hat,R2),ρ3hat)+a3_recal*np.dot(np.cross(ρ1hat,R3),ρ3hat))/-(np.dot(np.cross(ρ1hat,ρ2hat),ρ3hat))
                rho3=(a1_recal*(np.dot(np.cross(ρ2hat,R1),ρ1hat))-np.dot(np.cross(ρ2hat,R2),ρ1hat)+a3_recal*np.dot(np.cross(ρ2hat,R3),ρ1hat))/(a3_recal*np.dot(np.cross(ρ2hat,ρ3hat),ρ1hat))

                #initial values for three r vectors (unites: AU)
                r1=rho1*ρ1hat-R1
                r2=rho2*ρ2hat-R2
                r3=rho3*ρ3hat-R3

            
                f1=f_g(r2_new, v2_new, tau1)[0]
                g1=f_g(r2_new, v2_new, tau1)[1]
            
                f3=f_g(r2_new, v2_new, tau3)[0]
                g3=f_g(r2_new, v2_new, tau3)[1]

                r2_new=(g3*r1-g1*r3)/(f1*g3-f3*g1)
                v2_new=(f3*r1-f1*r3)/(f3*g1-f1*g3)*2*np.pi/365.2568983
                
                a1_recal=g3/(f1*g3-f3*g1)
                a3_recal=-g1/(f1*g3-f3*g1)
                count+=1
                
                r2_final=R_obliquity@r2_new
                v2_final=R_obliquity@v2_new

                print("rv",r2_final, v2_final)
                elements_final=orbit_elements([(R_obliquity@r2_new)[0], (R_obliquity@r2_new)[1],(R_obliquity@r2_new)[2], (R_obliquity@v2_new)[0], (R_obliquity@v2_new)[1], (R_obliquity@v2_new)[2]])
                
                print('2_new:', R_obliquity@r2_new, 'v2_new:', R_obliquity@v2_new)
                print(orbit_elements([(R_obliquity@r2_new)[0], (R_obliquity@r2_new)[1],(R_obliquity@r2_new)[2], (R_obliquity@v2_new)[0], (R_obliquity@v2_new)[1], (R_obliquity@v2_new)[2]]))
                #print("r2 error (%):", percent_error(r2_final, r_jpl))
                #print("v2 error (%):", percent_error(v2_final, v_jpl))
                print('element error(%)', percent_error(elements_final, orbital_jpl))

        return count



    

# ---------- Example call ----------
print(compD("1929RO_input.csv"))
#print(compD("mog_test_cases.csv"))
#2003 UD8,2459390.5,18 25 07.66,-17 26 32.9,-0.05995819309497526,1.014656459805135,-7.68181215494705e-05,2459400.5,18 15 28.02,-16 27 06.6,-0.2272484179571045,0.990991538857197,-7.72113173461264e-05,2459410.5,18 05 40.05,-15 30 37.6,-0.3882262247151484,0.9394135916377577,-7.234276212040242e-05,"(2459420.5,)",0.257831695555332,-1.572640424405053,0.07169980699394969,0.0136957506747166,0.00852180717124458,0.0004892986996858524,0.937668633710287,2.717433781497761,0.5363448943742929,3.88745445791311,238.3878022148351,108.3136804506047,344.1428964330095

# you should check the errors of r and v with the jpl information. The jpl for r are at row 20, 21, 22(starting from row 0), the v values are at row 23, 24, 25, and the orbital elements are at row 27, 28,29,30,31, 32.''

#1929 RO,2460842.645833,14 59 28.09,-13 34 49.9, 0.09019990733815525, 0.9283396167225063,-0.4023812036606655,2460849.614583,14 55 39.98,-13 34 34.0,-1.990370378756793E-01,9.147526157481032E-01,3.965406897547402E-01,2460859.8125,14 53 02.70, -13 47 13.3,-0.1275049971681530,0.9253804708004421,0.4011436494745536,2460849.614583,-0.8592509026617268,-1.8604986378421,-0.7319715816741732,0.01169839328499424,-0.001025045992282532,-0.001135716825486613,0.937668633710287,2.228780220492606E+00,0.2857592822606791,3.22983858572596,1.006507253733570E+02,2.480435642181720E+02,2.910583683225646E+02
#1929 RO, 2460846.629861111, 14 57 06.10, -13 33 48.24,2.287869340797292E-02, 1.015890208609806E+00, -9.193476332363419E-05, 2460849.625000000, 14 55 39.57, -13 34 27.9, -2.783052973045378E-02, 1.015995339456083E+00, -5.172356552513489E-05, 2460851.627777778, 14 54 51.935, -13 35 50.76,-6.170331517308077E-02, 1.014588612321705E+00, -9.050442044832192E-05, 2460849.625000000,1,1,1,1,1,1,1,2.228778564404452, 2.857575348459754E-1, 3.229839239734713,1.006507284892802E+022,480437604829543E+02,2.895803575206241E+02
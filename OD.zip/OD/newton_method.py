import numpy as np
def newton(x:float, M:float, e:float):
    e1=x-15
    tol=0.1
    iterations=0
    e0=x
    while (np.abs(e0-e1)>=tol and tol>=0.001):
        e0=e1
        e1=e0-(e0-e*np.sin(e0)-M)/(1-e*np.cos(e0))
        tol/=2
        iterations+=1
    return (e1,iterations,tol)

print(newton(0.1,0.42, 0.8))


    
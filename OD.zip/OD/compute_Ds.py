import numpy as np
import re


def parse_ra_string(ra_string: str) -> tuple[int, int, float]:
    parts = re.split(r"[:\s]+", ra_string.strip())
    h, m, s = int(parts[0]), int(parts[1]), float(parts[2])
    return h, m, s

def parse_dec_string(dec_string: str) -> tuple[int, int, float, bool]:
    dec_string = dec_string.strip()
    is_neg = dec_string[0] == "-"
    parts = re.split(r"[:\s]+", dec_string[1:])  # Skip sign
    d, m, s = int(parts[0]), int(parts[1]), float(parts[2])
    return d, m, s, is_neg

def convert_hms_to_deg(h: int, m: int, s: float) -> float:
    return 15.0 * (h + m / 60 + s / 3600)

def convert_dms_to_deg(d: int, m: int, s: float, is_neg: bool) -> float:
    deg = d + m / 60 + s / 3600
    return -deg if is_neg else deg


def read_observation_file(fname: str):
    with open(fname, "r", encoding="utf-8") as f:
        lines = [line.strip() for line in f if line.strip()]
    
    ra_string = lines[1]
    dec_string = lines[2]
    sun_vec = list(map(float, lines[3:6]))
    
    return ra_string, dec_string, sun_vec


def compD(file1: str, file2: str, file3: str):
    ra1s, dec1s, r1 = read_observation_file(file1)
    ra2s, dec2s, r2 = read_observation_file(file2)
    ra3s, dec3s, r3 = read_observation_file(file3)

    def rho_hat(ra_s, dec_s):
        ra_deg = convert_hms_to_deg(*parse_ra_string(ra_s))
        dec_deg = convert_dms_to_deg(*parse_dec_string(dec_s))
        ra_rad = np.deg2rad(ra_deg)
        dec_rad = np.deg2rad(dec_deg)
        return np.array([
            np.cos(ra_rad) * np.cos(dec_rad),
            np.sin(ra_rad) * np.cos(dec_rad),
            np.sin(dec_rad)
        ])

    ρ1 = rho_hat(ra1s, dec1s)
    ρ2 = rho_hat(ra2s, dec2s)
    ρ3 = rho_hat(ra3s, dec3s)

    r1 = np.array(r1)
    r2 = np.array(r2)
    r3 = np.array(r3)

    D0 = np.dot(ρ1, np.cross(ρ2, ρ3))
    D11 = np.dot(np.cross(r1, ρ2), ρ3)
    D12 = np.dot(np.cross(r2, ρ2), ρ3)
    D13 = np.dot(np.cross(r3, ρ2), ρ3)
    D21 = np.dot(np.cross(ρ1, r1), ρ3)
    D22 = np.dot(np.cross(ρ1, r2), ρ3)
    D23 = np.dot(np.cross(ρ1, r3), ρ3)
    D31 = np.dot(ρ1, np.cross(ρ2, r1))
    D32 = np.dot(ρ1, np.cross(ρ2, r2))
    D33 = np.dot(ρ1, np.cross(ρ2, r3))

    return D0, D11, D12, D13, D21, D22, D23, D31, D32, D33

# ---------- Example call ----------
print(compD("day1.txt", "day2.txt", "day3.txt"))

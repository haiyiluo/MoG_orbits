# writes the f and g functions for taylor expansion
import pandas as pd
import numpy as np
import csv
def f_g(r:np.array, v:np.array, tau, flag):
    r_mag=np.linalg.norm(r)
    if flag==False:
        f=1-tau**2/(2*r_mag**3)+np.dot(r,v)*tau**3/(2*r_mag**5)

        g=tau-tau**3/(6*r_mag**3)
        return f,g
    
    else:
        f=1-tau**2/(2*r_mag**3)+np.dot(r,v)*tau**3/(2*r_mag**5)+tau**4/(24*r_mag**3)*(3*(np.dot(v,v)/r_mag**2-1/r_mag**3)-15*(np.dot(r,v)/r_mag**2)**2+1/r_mag**3)

        g=tau-tau**3/(6*r_mag**3)+np.dot(r,v)*tau**4/(4*r_mag**5)
        return f,g
    

def orbit_elements(fname):
    # Open the CSV file
    with open(fname, 'r') as file:    
        reader = csv.reader(file)
        next(reader) #getting rid pf the header
    # Process each row
        for row in reader:
        # Strip whitespace from each element in the row
            stripped_row = [element.strip() for element in row]
            r=np.array([float(stripped_row[0]),float(stripped_row[1]),float(stripped_row[2])])
            v=np.array([float(stripped_row[3]),float(stripped_row[4]),float(stripped_row[5])])
            tau=float(stripped_row[6])
            order=(stripped_row[7])
            
            print(r,v,tau,order)
            print(f_g(r,v,tau,order))

#fname=pd.read_csv('f_and_g_test_cases.csv')                   
orbit_elements('f_and_g_test_cases.csv')
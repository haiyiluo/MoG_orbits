import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# Orbital elements (example values)
a = 2.228779 * 149597871  # Semi-major axis (km)
e = 0.285758              # Eccentricity
i = 3.229839              # Inclination (degrees)
Ω = 101.686146            # Longitude of ascending node (degrees)
ω = 241.874292            # Argument of periapsis (degrees)
ν = np.linspace(0, 360, 500)  # True anomaly (degrees)

# Convert degrees to radians
i_rad = np.radians(i)
Ω_rad = np.radians(Ω)
ω_rad = np.radians(ω)
ν_rad = np.radians(ν)

# Calculate the orbit in the perifocal coordinate system
r = (a * (1 - e**2)) / (1 + e * np.cos(ν_rad))
x_perifocal = r * np.cos(ν_rad)
y_perifocal = r * np.sin(ν_rad)
z_perifocal = np.zeros_like(ν_rad)

# Rotation matrices
R1 = np.array([[np.cos(Ω_rad), -np.sin(Ω_rad), 0],
               [np.sin(Ω_rad),  np.cos(Ω_rad), 0],
               [0,              0,             1]])

R2 = np.array([[1, 0,           0],
               [0, np.cos(i_rad), -np.sin(i_rad)],
               [0, np.sin(i_rad),  np.cos(i_rad)]])

R3 = np.array([[np.cos(ω_rad), -np.sin(ω_rad), 0],
               [np.sin(ω_rad),  np.cos(ω_rad), 0],
               [0,              0,             1]])

# Combined rotation matrix
rotation_matrix = R1 @ R2 @ R3

# Transform orbit into inertial frame
xyz_perifocal = np.array([x_perifocal, y_perifocal, z_perifocal])
xyz_inertial = rotation_matrix @ xyz_perifocal
x, y, z = xyz_inertial

# Create a 3D figure
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

# Plot orbit
ax.plot(x, y, z, label="Orbit", color='darkblue')
ax.scatter(0, 0, 0, color='yellow', label="Central Body")

# Plot the rectangular plane (e.g. orbital plane)
# We'll project it using the same rotation matrix (perifocal unit square)
rect_size = a * 0.1  # a small portion of orbit scale
rect = np.array([
    [0, rect_size, rect_size, 0],
    [0, 0, rect_size, rect_size],
    [0, 0, 0, 0]
])
rect_rotated = rotation_matrix @ rect
ax.plot(rect_rotated[0], rect_rotated[1], rect_rotated[2], color='skyblue', label='Orbital Plane')

# Add orbital element direction labels (Ω, ω, i)
arrow_scale = a * 1
# Ascending node vector (Ω)
asc_node = np.array([np.cos(Ω_rad), np.sin(Ω_rad), 0])
ax.quiver(0, 0, 0, asc_node[0], asc_node[1], asc_node[2], 
          color='red', length=arrow_scale, arrow_length_ratio=0.05,label='Ω: Ascending Node')

# Inclination arrow (i) – show tilt of orbital plane vs reference
ax.quiver(0, 0, 0, 0, 0, arrow_scale*np.sin(i_rad), 
          color='green',length=arrow_scale, arrow_length_ratio=0.05, label='i: Inclination')

# Argument of periapsis direction (ω), in orbital plane
peri_vec = rotation_matrix @ np.array([1, 0, 0])
ax.quiver(0, 0, 0, peri_vec[0], peri_vec[1], peri_vec[2], 
          color='orange', length=arrow_scale,arrow_length_ratio=0.05, label='ω: Periapsis')

# Labels and formatting
ax.set_xlabel("X (km)")
ax.set_ylabel("Y (km)")
ax.set_zlabel("Z (km)")
ax.set_title("3D Orbit with Orbital Element Directions")
ax.legend()
ax.grid(True)

plt.tight_layout()
plt.show()

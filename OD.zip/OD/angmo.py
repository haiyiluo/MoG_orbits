
import numpy as np
data=np.loadtxt('Luo_od1.txt')
def angmo (pos_ve:str):  
    x=pos_ve[0]/(1.49597870700E+8)
    y=pos_ve[1]/(1.49597870700E+8)
    z=pos_ve[2]/(1.49597870700E+8)
    vx=pos_ve[3]/(1.49597870700E+8)*(86400*365.2568983/(2*np.pi))
    vy=pos_ve[4]/(1.49597870700E+8)*(86400*365.2568983/(2*np.pi))
    vz=pos_ve[5]/(1.49597870700E+8)*(86400*365.2568983/(2*np.pi))
    r=[x,y,z]
    v=[vx,vy,vz]
    h = np.cross(r, v)
    return np.round(h,6)



print(angmo(data))


import numpy as np
from astropy.io import fits


tbl = fits.open("corr day 1 obs 1.fits")[1].data
#index: measured, field: ideal
rms_ra_1_1 = 3600*(np.mean((tbl.field_ra - tbl.index_ra)**2.))**0.5
ra_mean_1_1=np.mean(tbl.index_ra)
rms_dec_1_1 = 3600*(np.mean((tbl.field_dec - tbl.index_dec)**2.))**0.5
dec_mean_1_1=np.mean(tbl.index_dec)

tbl1 = fits.open("corr_obs1_time2.fits")[1].data
rms_ra_1_2 = 3600*(np.mean((tbl1.field_ra - tbl1.index_ra)**2.))**0.5
ra_mean_1_2=np.mean(tbl1.index_ra)
rms_dec_1_2 = 3600*(np.mean((tbl1.field_dec - tbl1.index_dec)**2.))**0.5
dec_mean_1_2=np.mean(tbl1.index_dec)

tbl2 = fits.open("corr_obs1_time3.fits")[1].data
rms_ra_1_3 = 3600*(np.mean((tbl2.field_ra - tbl2.index_ra)**2.))**0.5
ra_mean_1_3=np.mean(tbl2.index_ra)
rms_dec_1_3 = 3600*(np.mean((tbl2.field_dec - tbl2.index_dec)**2.))**0.5
dec_mean_1_3=np.mean(tbl2.index_dec)

ra_mean_day1=(ra_mean_1_1+ra_mean_1_2+ra_mean_1_3)/3
dec_mean_day1=(dec_mean_1_1+dec_mean_1_2+dec_mean_1_3)/3
rms_ra_day1=(rms_ra_1_1+rms_ra_1_2+rms_ra_1_3)/3
rms_dec_day1=(rms_dec_1_1+rms_dec_1_2+rms_dec_1_3)/3
print(ra_mean_day1,dec_mean_day1,rms_ra_day1,rms_dec_day1)

tbl3 = fits.open("corr_obs2_time1.fits")[1].data
#index: measured, field: ideal
rms_ra_2_1 = 3600*(np.mean((tbl3.field_ra - tbl3.index_ra)**2.))**0.5
ra_mean_2_1=np.mean(tbl3.index_ra)
rms_dec_2_1 = 3600*(np.mean((tbl3.field_dec - tbl3.index_dec)**2.))**0.5
dec_mean_2_1=np.mean(tbl3.index_dec)

tbl4 = fits.open("corr_obs2_time2.fits")[1].data
rms_ra_2_2 = 3600*(np.mean((tbl4.field_ra - tbl4.index_ra)**2.))**0.5
ra_mean_2_2=np.mean(tbl4.index_ra)
rms_dec_2_2 = 3600*(np.mean((tbl4.field_dec - tbl4.index_dec)**2.))**0.5
dec_mean_2_2=np.mean(tbl4.index_dec)

tbl5 = fits.open("corr_obs2_time3.fits")[1].data
rms_ra_2_3 = 3600*(np.mean((tbl5.field_ra - tbl5.index_ra)**2.))**0.5
ra_mean_2_3=np.mean(tbl5.index_ra)
rms_dec_2_3 = 3600*(np.mean((tbl5.field_dec - tbl5.index_dec)**2.))**0.5
dec_mean_2_3=np.mean(tbl5.index_dec)

ra_mean_day2=(ra_mean_2_1+ra_mean_2_2+ra_mean_2_3)/3
dec_mean_day2=(dec_mean_2_1+dec_mean_2_2+dec_mean_2_3)/3
rms_ra_day2=(rms_ra_2_1+rms_ra_2_2+rms_ra_2_3)/3
rms_dec_day2=(rms_dec_2_1+rms_dec_2_2+rms_dec_2_3)/3
print(ra_mean_day2,dec_mean_day2,rms_ra_day2,rms_dec_day2)



tbl6 = fits.open("corr_obs3_time1.fits")[1].data
#index: measured, field: ideal
rms_ra_3_1 = 3600*(np.mean((tbl6.field_ra - tbl6.index_ra)**2.))**0.5
ra_mean_3_1=np.mean(tbl6.index_ra)
rms_dec_3_1 = 3600*(np.mean((tbl6.field_dec - tbl6.index_dec)**2.))**0.5
dec_mean_3_1=np.mean(tbl6.index_dec)

tbl7 = fits.open("corr_obs3_time2.fits")[1].data
rms_ra_3_2 = 3600*(np.mean((tbl7.field_ra - tbl7.index_ra)**2.))**0.5
ra_mean_3_2=np.mean(tbl7.index_ra)
rms_dec_3_2 = 3600*(np.mean((tbl7.field_dec - tbl7.index_dec)**2.))**0.5
dec_mean_3_2=np.mean(tbl7.index_dec)

tbl8 = fits.open("corr_obs3_time3.fits")[1].data
rms_ra_3_3 = 3600*(np.mean((tbl8.field_ra - tbl8.index_ra)**2.))**0.5
ra_mean_3_3=np.mean(tbl8.index_ra)
rms_dec_3_3 = 3600*(np.mean((tbl8.field_dec - tbl8.index_dec)**2.))**0.5
dec_mean_3_3=np.mean(tbl8.index_dec)

ra_mean_day3=(ra_mean_3_1+ra_mean_3_2+ra_mean_3_3)/3
dec_mean_day3=(dec_mean_3_1+dec_mean_3_2+dec_mean_3_3)/3
rms_ra_day3=(rms_ra_3_1+rms_ra_3_2+rms_ra_3_3)/3
rms_dec_day3=(rms_dec_3_1+rms_dec_3_2+rms_dec_3_3)/3
print(ra_mean_day3,dec_mean_day3,rms_ra_day3,rms_dec_day3)

ra_mean=(ra_mean_day1+ra_mean_day2+ra_mean_day3)/3
dec_mean=(dec_mean_day1+dec_mean_day2+dec_mean_day3)/3
rms_ra=(rms_ra_day1+rms_ra_day2+rms_ra_day3)/3
rms_dec=(rms_dec_day1+rms_dec_day2+rms_dec_day3)/3



X= 7.617333293475486E-01 *149597871
Y =-1.758125446003031E+00 *149597871
Z = 3.379874974061844E-02*149597871
X = 6.373236262266135E-01 *149597871
Y =-1.899351869648904E+00 *149597871
Z = 3.777281154864846E-02*149597871
F=(6.674E-11*6.4191E23*7.35E21/(X**2+Y**2+Z**2))
print('radius:',np.sqrt((X**2+Y**2+Z**2))/149597871)
print('force of mars on asteroid',F)
print('acceleration of asteroid:', F/7.35E21)
print('final:', ra_mean, dec_mean, 'rms of ra:', rms_ra, 'rms of dec:', rms_dec)